#!/usr/bin/env python
# -*- coding: utf-8 -*-
import socket
import fcntl
import struct
import threading
import subprocess as sp
import os
import stat
import time
import select

from signal import SIGTERM, SIGKILL
from os import kill, waitpid
import commands
vsmProc  = ''
LENGTH = 4096
LENGTHFILE = 1024

def get_ip_address(ifname, isBroadcast=0):
    try:
       s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
       fcaddr = fcntl.ioctl(s.fileno(),0x8915,struct.pack('256s', ifname[:15]))
    except IOError:
       return ""
    laddr = list(fcaddr[20:24])
    if isBroadcast:
        laddr[3]='\xFF'
    ipaddr= "".join(laddr)
    return socket.inet_ntoa(ipaddr)

def get_device_name():
    ips = sp.check_output(['uname','-n'])
    words = ips.split()
    if words[0] != "":
        return words[0]
    else:
        return "Unknown"

def clear_ports():
    try:
        cleardports = sp.check_output(['sudo','fuser','-k', '-n' ,'tcp', '57893'])
        print cleardports
        cleardports = sp.check_output(['sudo','fuser','-k', '-n' ,'udp', '57892'])
        print cleardports
    except sp.CalledProcessError as e:
        print "port 57892 and 57893 are not in use"

# listen for broadcasts on 50002 and reply with host name
def broad_cast_listen():    
    bcastAddr = '0.0.0.0' #get_ip_address(interface,1)
    addr = (bcastAddr , 50002)  # host, port
    # Create socket and bind to address
    UDPSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    #UDPSock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # Allow sock reuse
    UDPSock.bind(addr)
    # Receive messages
    while True:
        print "Wait on recvfrom: ",bcastAddr
        data, addr = UDPSock.recvfrom(1024)
        print "Read recvfrom",addr,": ",data 
        # Reply to PC with host name. Reply packet will carry our IP addr
        data = get_device_name()
        UDPSock.sendto(data, addr)
        print( "sent host id to:", addr)

def receive_execute_file():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    host=''
    port=50009
    s.bind((host,port))
    print"host is: ", host
    print"port is: ", port
    s.listen(5)
    global vsmProc 
    vsmProc  =''
    os.system("export DISPLAY=:10.0")
    while True:
        try:
            c,addr = s.accept()
            print"Got Connection From", addr
            if str(addr) != '':
                clear_ports()
                print "Receiving..."
                file_attrb = c.recv(LENGTH)
                print "Received: ", file_attrb
                if vsmProc  != '':
                    parentProcessID = vsmProc.pid
                    cmdstring = "ps --ppid " +  str(parentProcessID) + " | awk '{print $1}' | awk END{print}"
                    statusnow, childPID = commands.getstatusoutput(cmdstring)
                    print "*****Killing the Parent and Child Processes***"
                    kill(int(childPID), SIGKILL)
                    print "** Done Killing the child process"
                    kill(vsmProc.pid, SIGKILL)
                    c.send('OK')
#                    c.close()
                    time.sleep(2)
                    continue
                if str(file_attrb) == 'kill':  # just kill child proc if download file is empty
                    c.send('OK')
                    print "continuing exec loop:", file_attrb
                    c.close()
                    continue
                file_attrb = file_attrb.split(":")
                file_size = int(file_attrb[0])
                file_name = str(file_attrb[1])
                print "file size is " +str(file_size)
                print "file name is " +str(file_name)
                path = '/home/pi/Downloads/'+file_name
                if os.path.isfile(path):
                    os.remove(path)
                f = open(path ,'wb')
                data =""
                recvd=0
                print "** c.send: received file attributes"
                c.send("received file attributes")
                print "recvd " +str(recvd)
                while file_size > recvd:
                    print "** data = c.recv(LENGTH)"
                    data = c.recv(LENGTH)
                    if not data:
                        continue
                    recvd =recvd+len(data)
                    f.write(data)
                f.close()
                print "Received file"
                st = os.stat(path)
                os.chmod(path, st.st_mode | stat.S_IEXEC)
                if vsmProc  == '':
                    vsmProc = sp.Popen(['sudo',path],stdout=sp.PIPE, stderr=sp.PIPE)
                    y=select.poll()
                    y.register(vsmProc.stderr,select.POLLIN)
                    print "File running"
                    time.sleep(1)
#                fcntl.fcntl( vsmProc.stdout.fileno(),fcntl.F_SETFL,
#                  fcntl.fcntl(vsmProc.stdout.fileno(), fcntl.F_GETFL) | os.O_NONBLOCK,)
                    output = 'OK'
                    if y.poll(1):  # Report any startup error
                        output = vsmProc.stderr.read()
                    c.send(output)
                    print "download complete msg:",output
                    c.close()
                    t = threading.Thread(target=waitForChildProcess)
                    t.start()
        except Exception,err:
            print ("Exception: Restarting download daemon",err)


def waitForChildProcess():
    print "Start wait on child process..."
    global vsmProc 
    #while True:
    try:
        if vsmProc  != '':
            vsmProc.wait()
            print "Child process finished"
           # print vsmProc 
            vsmProc = ''
    except AttributeError:
        print "KIlling the Previous Process and waiting for signal from Child"
        kill(vsmProc.pid, SIGKILL)
        waitpid(vsmProc.pid,0)
        print "No Zombie Process, after force kill"
    print "End proc wait"
                
t = threading.Thread(target=broad_cast_listen)
t.start()
receive_execute_file()

