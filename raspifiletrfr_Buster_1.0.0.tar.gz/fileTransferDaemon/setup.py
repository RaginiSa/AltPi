import os
print "Creating the Altair File Transfer Daemon"
os.system("sudo cp altair_file_transfer.service /lib/systemd/system/altair_file_transfer.service")
os.system("sudo cp VissimDaemon.py /usr/sbin")
print "Giving daemon the permissions"
os.system("sudo chmod 644 /lib/systemd/system/altair_file_transfer.service")
print "Giving the execute permissions for the python file"
os.system("chmod +x VissimDaemon.py")
os.system("sudo systemctl daemon-reload")
os.system("cd /lib/systemd/system/")
os.system("sudo systemctl enable altair_file_transfer.service")
os.system("sudo systemctl start altair_file_transfer.service")
os.system("sudo systemctl status altair_file_transfer.service")
