#!/bin/sh
cd /home/pi/fileTransferDaemon
sudo python setup.py

cd /home/pi
sudo ldconfig ~/lib ~/lib/opencv


